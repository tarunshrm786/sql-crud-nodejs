const express = require("express");
const mysql = require("mysql");

const app = express();

//Create Connections

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "crud"
});

//connect to database
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("Connection done");
});

//create DB
app.post("/createdb", (req, res) => {
  const sql = "CREATE DATABASE crud_operation";
  db.query(sql, (err, result) => {
    if (err) throw err;
    console.log("result");
    res.send("Database Created");
  });
});

//create table
app.post("/createtable", (req, res) => {
  const sql =
    "CREATE TABLE person(id INT AUTO_INCREMENT, first_name VARCHAR(50) NOT NULL, last_name VARCHAR(50) NOT NULL, age INT,dob DATE,address VARCHAR(255),contact_number VARCHAR(15),PRIMARY KEY (id) )";
  db.query(sql, (err, result) => {
    if (err) throw err;
    console.log("result");
    res.send("Person table created");
  });
});

//Insert person detail 1
app.post("/addperson1", (req, res) => {
  const post = { id: 1, first_name: "Shiv", last_name: "Pandey", age: 25, dob: "26-03-1998", address: "257C Kidwai Nagar", contact_number: 8318919787};
  const sql = "INSERT INTO person SET ?";
  const query = db.query(sql, post, (err, result) => {
    if (err) throw err;
    console.log("result");
    res.send("Person added successfully");
  });
});

//Insert person detail 2
app.post("/addperson2", (req, res) => {
  const post = { id: 2, first_name: "Mukesh", last_name: "Tiwari", age: 20, dob: "21-07-2004", address: "257C George town", contact_number: 8318019721};
  const sql = "INSERT INTO person SET ?";
  const query = db.query(sql, post, (err, result) => {
    if (err) throw err;
    console.log("result");
    res.send("Person added successfully");
  });
});

//Select person details
app.get("/getperson", (req, res) => {
  const sql = "SELECT * FROM person";
  const query = db.query(sql, (err, result) => {
    if (err) throw err;
    console.log(result);
    res.send("Person detail fetched");
  });
});

//Select single person detail
app.get("/getpersonbyid/:id", (req, res) => {
  const sql = `SELECT * FROM person WHERE id= ${req.params.id}`;
  const query = db.query(sql, (err, result) => {
    if (err) throw err;
    console.log(result);
    res.send("Single detail of person fetched");
  });
});

//Update person detail by id
app.put("/updateperson/:id", (req, res) => {
  const newFirstName = "Ganesh";
  const sql = `UPDATE person SET first_name= '${newFirstName}' WHERE id=${req.params.id}`;
  const query = db.query(sql, (err, result) => {
    if (err) throw err;
    console.log(result);
    res.send("Person details updated");
  });
});

//Delete person detail
app.delete("/deleteperson/:id", (req, res) => {
  const sql = `DELETE FROM person WHERE id=${req.params.id}`;
  const query = db.query(sql, (err, result) => {
    if (err) throw err;
    console.log("result");
    res.send("Person details deleted");
  });
});
 

app.listen("8000", () => {
  console.log("Server is successfully running on port 8000");
});